Q1��
simulate the flower 
defult is rose, 5 petals, price is 1.0

Q2:
input the polynomial(example: 6*x^7-8*x^1)
then it will take the derivative of it.

Q3:
    # Defult 8 fished, 4 bears, river lengh is 140, simulate 800 times)
    e = Environment(8,4,140,800)
    e.simulate()

it will then out put the result.
