How to run the code?

Please make sure Python has been installed.
Double click to open the .py file or open with IDLE to run.

Q1:
Enter final account value. Enter annual interest rate in percent. Enter the number of years.
Then it will display the initial deposit amount.

Q2:
Enter an integer. 
Then it will display each of the numbers one by one.

Q3:
Enter a number.
Then it will output the samllest interger such that its square is greater than the input number.
(If the input number is negative, it will point out the error.)

Q4:
Enter a number (N).
It will print a table with N rows and 3 columns. 
In the mth row, it output three numbers: m, m+1, and m**(m+1).

Q5:
Enter an integer(N).
Then it will print all the prime numbers which are smaller than N.
And it will output at most 8 prime numbers in each line.

Q6:
Enter"s", "c"or"t"to specify a trigonometric function (sinx, cosx, tanx).
Enter the interval start points a, and enter the interval end point b.
Enter the number of sub-intervals n. 
Then it will calculate the numerical integration of f over [a, b] and output the result.